<?php
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;

    require 'phpmailer/src/Exception.php';
    require 'phpmailer/src/PHPMailer.php';

    $mail = new PHPMailer(true);
    $mail->CharSet = 'UTF-8';
    $mail->IsHTML(true);

    //ОТ кого письмо 
    $mail->setForm('mailer2024@mail.ru', 'MAILER');
    //Кому отправить
    $mail->addAddress('gadzhiev-2019@bk.ru');
    //Тема письма 
    $mail->Subject = 'Здравствуйте. У вас новая Заяввка на сайте';

    //Тело Пиьсма
    $body = '<h1>Посетитель оставил заявку</h1>';

    if(trim(!empty($_POST['name']))) {
        $body.='<p><strong>Имя:</strong> '.$_POST['name'].'</p>';
    }
    if(trim(!empty($_POST['phone']))) {
        $body.='<p><strong>Телефон:</strong> '.$_POST['phone'].'</p>';
    }

    //Отправялем 
    $mail->Body = $body;

    if (!$mail->send()) {
        $message = 'Ошибка';
    }
    else {
        $message = "Данные отправлены!";
    }

    $response = ['message' => $message];

    header('Content-Type: application/json');
    echo json_encode($response);

?>