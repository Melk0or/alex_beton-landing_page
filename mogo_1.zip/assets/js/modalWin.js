let modal = document.getElementById("myModal");
let openBtn = document.getElementById("myBtn");
let openBtn1 = document.getElementById("openBtn1")
let openBtn2 = document.getElementById("openBtn2")
let closeBtn = document.getElementsByClassName("close")[0];

let html = document.body;

openBtn.onclick = function () {
    modal.style.display = "block";
    html.style.overflowY = "hidden";
}

openBtn1.onclick = function () {
    modal.style.display = "block";
    html.style.overflowY = "hidden";
}

openBtn2.onclick = function () {
    modal.style.display = "block";
    html.style.overflowY = "hidden";
}

closeBtn.onclick = function () {
    modal.style.display = "none";
    html.style.overflowY = "visible";
}

